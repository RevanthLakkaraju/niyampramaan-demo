"""Local demonstration identities and institution-side case operations.

Credentials are public demo fixtures. This is not production identity proofing,
SSO, or authorisation to access an actual AICTE service.
"""
from __future__ import annotations
import base64
import copy
import hashlib
import hmac
import secrets
import threading
import time
from engine import now

ACCOUNTS = {
    'institution': {'username': 'institution.demo', 'password': 'Institution@26', 'name': 'S. Mehta', 'designation': 'Institution representative'},
    'reviewer': {'username': 'reviewer.demo', 'password': 'Review@26', 'name': 'A. Rao', 'designation': 'AICTE reviewer · demonstration role'},
}

class Sessions:
    def __init__(self):
        self.lock = threading.RLock()
        self.tokens = {}
        self.tour = None
        self.hashes = {r: hashlib.pbkdf2_hmac('sha256', a['password'].encode(), ('np-demo-'+r).encode(), 120000) for r,a in ACCOUNTS.items()}

    def login(self, role, username, password):
        if role not in ACCOUNTS or not isinstance(password, str) or len(password)>200:
            raise ValueError('Incorrect demonstration login details.')
        digest=hashlib.pbkdf2_hmac('sha256', password.encode(), ('np-demo-'+role).encode(), 120000)
        if username != ACCOUNTS[role]['username'] or not hmac.compare_digest(digest,self.hashes[role]):
            raise ValueError('Incorrect demonstration login details.')
        token=secrets.token_urlsafe(32)
        identity={k:v for k,v in ACCOUNTS[role].items() if k!='password'}
        identity.update(role=role,local_demo=True)
        with self.lock:
            self.tokens={k:v for k,v in self.tokens.items() if v['expires']>time.time()}
            self.tokens[token]={'identity':identity,'expires':time.time()+8*3600}
        return token, identity

    def get(self,token):
        with self.lock:
            session=self.tokens.get(token)
            return copy.deepcopy(session['identity']) if session and session['expires']>time.time() else None

    def begin_tour(self, client, restart=False):
        with self.lock:
            if self.tour and self.tour['expires']>time.time() and not restart:
                raise ValueError('A walkthrough is already running. Use Restart walkthrough to replace it and begin from scene 1.')
            run=secrets.token_urlsafe(24)
            self.tour={'run':run,'client':client,'expires':float('inf')}
            return run

    def check_tour(self,run,client):
        with self.lock:
            if self.tour and self.tour['expires']<=time.time():self.tour=None
            return not self.tour or (run==self.tour['run'] and client==self.tour['client'])

    def end_tour(self,run,client):
        with self.lock:
            if self.tour and run==self.tour['run'] and client==self.tour['client']:self.tour=None

    def logout(self,token):
        with self.lock:
            self.tokens.pop(token,None)

class Portal:
    def __init__(self, store):
        self.store=store

    def case_for(self,identity):
        state=self.store.case()
        state.setdefault('submission',None)
        state.setdefault('attachments',[])
        state['capabilities']['authentication']='Local cookie sessions with two server-enforced demonstration roles'
        if identity['role']=='reviewer':
            return state
        # Published request instructions are shared; internal reviewer notes and
        # audit records are not included in the institution's response payload.
        result={k:copy.deepcopy(state[k]) for k in ['id','institution','institution_id','academic_year','application_type','status','review_date','rule_version','documents','requests','revisions','submission','attachments','capabilities']}
        for attachment in result['attachments']:
            attachment.pop('assessment_note',None)
        result['progress']=[{k:e[k] for k in ['timestamp','action','detail']} for e in state['events'] if e['action'] in {'application_submitted','institution_response','replacement_received','expiry_rechecked','attachment_saved'}]
        if state.get('recommendation'):
            result['next_step']=state['recommendation']['label']
        return result

    def precheck(self):
        from engine import analyse_documents, load_manifest, load_rules
        docs=load_manifest(self.store.root)['documents']
        pages={d['id']:self.store.evidence(d['id'])['pages'] for d in docs}
        result=analyse_documents(docs,pages,load_rules(self.store.root))
        return {'checks':result['checks'],'findings':[{k:f[k] for k in ['id','title','summary','next_action','source']} for f in result['findings']],
                'notice':'Submission readiness check on the original supplied PDFs. It does not change the reviewer’s record, replace a revised document or establish approval.'}

    def submit(self,payload):
        contact=str(payload.get('contact','')).strip()
        if payload.get('declaration') is not True or not 3<=len(contact)<=100:
            raise ValueError('Enter a representative name and accept the demonstration declaration.')
        with self.store.lock:
            s=self.store._read()
            if not s.get('submission'):
                s['submission']={'reference':s['id'],'submitted_at':now(),'contact':contact,'category':'Extension of Approval','declaration':True}
                if not s.get('analysis'):s['status']='Submitted for preliminary scrutiny'
                self.store._event(s,'application_submitted','Institution submitted the synthetic EoA case and its seven source documents. Reference '+s['id']+'.',actor=contact)
                self.store._write(s)
        return {'submitted':True,'reference':s['id']}

    def response(self,payload):
        note=str(payload.get('note','')).strip()
        if not 10<=len(note)<=2000:raise ValueError('Enter a response of 10–2,000 characters.')
        with self.store.lock:
            s=self.store._read()
            req=next((r for r in s['requests'] if r['id']==payload.get('request_id')),None)
            if not req or req['status']!='Awaiting institution response':raise ValueError('Choose an open rectification request.')
            req.update(response=note,response_at=now(),status='Response received; officer review pending')
            # Text alone cannot resolve the underlying finding.
            self.store._event(s,'institution_response',note,actor='Institution representative',request_id=req['id'],finding_id=req['finding_id'])
            self.store._write(s)
        return {'received':True,'status':'Officer review pending'}

    def save_attachment(self,payload):
        inspected=self.store.upload(payload.get('filename',''),payload.get('content_base64',''))
        category=payload.get('category','')
        if category not in {'Infrastructure evidence','Institution explanation','Additional certificate'}:raise ValueError('Choose the purpose of the supplementary document.')
        with self.store.lock:
            s=self.store._read();attachments=s.setdefault('attachments',[])
            existing=next((a for a in attachments if a['sha256']==inspected['sha256']),None)
            if existing:return existing
            aid='ATT-'+secrets.token_hex(6)
            folder=self.store.db_path.parent/'uploads';folder.mkdir(parents=True,exist_ok=True)
            (folder/(aid+'.pdf')).write_bytes(base64.b64decode(payload['content_base64'],validate=True))
            saved={k:inspected[k] for k in ['filename','sha256','bytes','readable','fields','duplicate_matches']}
            saved.update(id=aid,category=category,pages=len(inspected['pages']),timestamp=now(),status='Awaiting officer assessment',url='/api/attachments/'+aid)
            attachments.append(saved)
            self.store._event(s,'attachment_saved',category+': '+saved['filename']+' retained as supplementary evidence; original documents unchanged.',actor='Institution representative',attachment_id=aid)
            self.store._write(s)
        return saved

    def assess_attachment(self,payload):
        note=str(payload.get('note','')).strip()
        if not 10<=len(note)<=2000:raise ValueError('Enter an assessment reason of 10–2,000 characters.')
        with self.store.lock:
            s=self.store._read();a=next((a for a in s.get('attachments',[]) if a['id']==payload.get('attachment_id')),None)
            if not a:raise ValueError('Unknown supplementary evidence.')
            if a['status']=='Assessed by officer' and a.get('assessment_note')==note:
                return {'assessed':True}
            a.update(status='Assessed by officer',assessment_note=note,reviewed_at=now())
            self.store._event(s,'attachment_assessed',note,actor=s['reviewer'],attachment_id=a['id'])
            self.store._write(s)
        return {'assessed':True}
