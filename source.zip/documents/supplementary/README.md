# Additional upload samples

These files are outside the original seven-document case register. They are intended for demonstrating local PDF upload behaviour. All contents are synthetic.

## Infrastructure schedule

Upload `infrastructure-schedule.pdf` to demonstrate attaching an additional readable PDF. The schedule contains illustrative counts of rooms, laboratories, terminals and reading seats. They are unverified declarations, not certified capacity or evidence that official requirements have been met. Uploading the schedule must not automatically resolve the intake-change finding.

## Duplicate receipt

Upload `payment-receipt-duplicate.pdf` to demonstrate exact duplicate detection. It has a different filename but is byte-identical to the original `documents/payment-receipt.pdf`. A SHA-256 comparison will identify the identical file. An exact duplicate can result from a repeat upload and is not, by itself, proof of document alteration or fraud.

## Reproduction and limitations

Run `generate_supplementary.py` using the same ReportLab environment as `generate_documents.py`. The generator recreates the infrastructure schedule, copies the current original receipt byte-for-byte, checks matching SHA-256 hashes, and renders optional PNG previews when Poppler is installed.

No scanned or deliberately degraded sample is included. These documents have native text and support the prototype's actual PDF extraction. They must not be presented as evidence of OCR on image-only documents.
