"""Local demonstration engine. No government services or AI models are contacted.

Native PDF text is extracted by pypdf. Transparent Python rules compare the
extracted fields. Issuer responses are explicit fixtures. DEMO rule identifiers
are not AICTE Handbook clauses. The rules never grant or refuse approval.
"""

from __future__ import annotations

from datetime import date, datetime, timezone
import base64
import binascii
import hashlib
import io
import json
from pathlib import Path
import re
import sqlite3
import threading
from typing import Any
import uuid


ROOT = Path(__file__).resolve().parent
REVIEW_DATE = date(2026, 10, 28)
DOC_DEFAULTS = [
    {"id": "application", "title": "Current application", "filename": "application.pdf", "pages": 2, "kind": "Application"},
    {"id": "previous-eoa", "title": "Previous EoA", "filename": "previous-eoa.pdf", "pages": 1, "kind": "Baseline"},
    {"id": "fire", "title": "Fire safety certificate", "filename": "fire-safety.pdf", "pages": 1, "kind": "Certificate"},
    {"id": "faculty", "title": "Faculty return", "filename": "faculty-return.pdf", "pages": 1, "kind": "Institutional return"},
    {"id": "occupancy", "title": "Occupancy certificate", "filename": "occupancy.pdf", "pages": 1, "kind": "Infrastructure"},
    {"id": "payment", "title": "Payment receipt", "filename": "payment-receipt.pdf", "pages": 1, "kind": "Receipt"},
    {"id": "institutional-record", "title": "Institutional record", "filename": "institutional-record.pdf", "pages": 1, "kind": "Reference record"},
]


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def load_rules(root: Path = ROOT) -> list[dict[str, Any]]:
    return json.loads((root / "rules.json").read_text(encoding="utf-8"))


def load_manifest(root: Path = ROOT) -> dict[str, Any]:
    path = root / "case_manifest.json"
    manifest = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    case = dict(manifest.get("case", {}))
    case.update({key: value for key, value in manifest.items() if key != "case"})
    case["documents"] = case.get("documents", DOC_DEFAULTS)
    return case


def extract_pages(path: Path) -> list[dict[str, Any]]:
    try:
        from pypdf import PdfReader
    except ImportError as exc:
        raise RuntimeError("PDF reading requires pypdf. Run python3 -m pip install pypdf in your Python environment.") from exc
    reader = PdfReader(str(path))
    return [{"page": index + 1, "text": page.extract_text() or ""} for index, page in enumerate(reader.pages)]


def field(pages_by_id: dict[str, list[dict[str, Any]]], document_id: str, labels: list[str]) -> tuple[str | None, dict[str, Any] | None]:
    """Return exactly the extracted value and the actual page line that supports it."""
    for page in pages_by_id.get(document_id, []):
        for label in labels:
            pattern = rf"^\s*{re.escape(label)}\s*[:：]\s*(.+?)\s*$"
            match = re.search(pattern, page["text"], flags=re.I | re.M)
            if match:
                return match.group(1).strip(), {"document_id": document_id, "page": page["page"], "quote": match.group(0).strip()}
    return None, None


def integer(value: str | None) -> int | None:
    match = re.search(r"\b\d[\d,]*\b", value or "")
    return int(match.group().replace(",", "")) if match else None


def parsed_date(value: str | None) -> date | None:
    for form in ("%d %B %Y", "%d %b %Y", "%Y-%m-%d", "%d/%m/%Y"):
        try:
            return datetime.strptime((value or "").strip(), form).date()
        except ValueError:
            pass
    return None


def analyse_documents(documents: list[dict[str, Any]], pages_by_id: dict[str, list[dict[str, Any]]], rules: list[dict[str, Any]], review_date: date = REVIEW_DATE) -> dict[str, Any]:
    rule_map = {r["id"]: r for r in rules}
    facts, findings, checks = [], [], []

    def finding(key: str, title: str, severity: str, category: str, summary: str, observed: Any, expected: Any, source: dict | None, rule_id: str, next_action: str, comparison_source: dict | None = None):
        result = {"id": key, "title": title, "severity": severity, "status": "open", "category": category,
                  "summary": summary, "observed": observed, "expected": expected, "source": source,
                  "comparison_source": comparison_source, "rule": rule_map[rule_id], "next_action": next_action,
                  "officer_note": None, "verification": None}
        findings.append(result)
        return result

    missing = [d for d in documents if not pages_by_id.get(d["id"]) or not any(p["text"].strip() for p in pages_by_id[d["id"]])]
    checks.append({"id": "completeness", "label": "Required documents", "result": "attention" if missing else "pass",
                   "detail": f"{len(documents) - len(missing)} of {len(documents)} demonstration documents contain readable text."})
    for doc in missing:
        finding("missing-" + doc["id"], f"{doc['title']} requires readable evidence", "attention", "Document completeness",
                "The required file is absent or has no extractable text. A scanned file needs OCR or manual review; it is not proof of invalidity.",
                "No readable PDF text", "Readable source evidence", None, "DEMO-CHECK-01", "Supply a readable copy or assign manual document reading.")

    app_id, app_id_src = field(pages_by_id, "application", ["Institution ID", "Permanent Institution ID"])
    reg_id, reg_id_src = field(pages_by_id, "institutional-record", ["Institution ID", "Permanent Institution ID"])
    prior_id, prior_id_src = field(pages_by_id, "previous-eoa", ["Institution ID", "Permanent Institution ID"])
    requested, req_src = field(pages_by_id, "application", ["Requested intake"])
    approved, prev_src = field(pages_by_id, "previous-eoa", ["Approved intake"])
    requested_number, approved_number = integer(requested), integer(approved)
    changed_intake = requested_number is not None and approved_number is not None and requested_number != approved_number
    facts.append({"key": "requested_intake", "label": "Annual intake", "current": requested_number,
                  "previous": approved_number, "changed": changed_intake, "source": req_src,
                  "comparison_source": prev_src, "state": "changed" if changed_intake else ("unchanged" if approved_number is not None else "unavailable")})
    if changed_intake:
        finding("intake-change", "Requested intake has changed", "review", "Changed fact",
                f"The application requests {requested_number} seats; the previous EoA records {approved_number}. This is a request for change, not an established violation.",
                f"{requested_number} seats requested", f"{approved_number} seats previously approved", req_src, "DEMO-INTAKE-02",
                "Review the intake-change request and supporting capacity evidence before forwarding for a decision.", prev_src)
    elif requested_number is None or approved_number is None:
        finding("intake-unreadable", "Intake comparison needs manual review", "review", "Baseline unavailable",
                "Both requested and previously approved intake must be readable before a comparison is possible. No unchanged status has been assumed.",
                requested if requested else "Requested intake unavailable", approved if approved else "Previous approved intake unavailable",
                req_src, "DEMO-INTAKE-02", "Obtain the missing source field and complete the intake comparison.", prev_src)
    checks.append({"id": "intake", "label": "Intake against previous EoA", "result": "attention" if changed_intake else ("pass" if requested_number is not None and approved_number is not None else "pending"),
                   "detail": f"{approved_number} → {requested_number} seats. Change-specific evidence review is required." if changed_intake else ("No change in the extracted intake values." if approved_number is not None and requested_number is not None else "A source value is unavailable; manual comparison is required.")})

    facts.append({"key": "institution_id", "label": "Institution identifier", "current": app_id, "previous": reg_id or prior_id,
                  "changed": bool(app_id and (reg_id or prior_id) and app_id != (reg_id or prior_id)), "source": app_id_src,
                  "comparison_source": reg_id_src or prior_id_src, "state": "unchanged" if app_id and app_id == (reg_id or prior_id) else "review"})
    name, name_src = field(pages_by_id, "application", ["Institution name"])
    prev_name, prev_name_src = field(pages_by_id, "previous-eoa", ["Institution name"])
    facts.append({"key": "institution_name", "label": "Institution name", "current": name, "previous": prev_name,
                  "changed": bool(name and prev_name and name.casefold() != prev_name.casefold()), "source": name_src,
                  "comparison_source": prev_name_src, "state": "unchanged" if name and prev_name and name.casefold() == prev_name.casefold() else "review"})

    expiry, expiry_src = field(pages_by_id, "fire", ["Valid until", "Valid till", "Expiry date"])
    expiry_date = parsed_date(expiry)
    is_expired = expiry_date is not None and expiry_date < review_date
    facts.append({"key": "valid_until", "label": "Fire certificate validity", "current": expiry, "previous": "Assessment: " + review_date.strftime("%d %B %Y"),
                  "changed": False, "source": expiry_src, "comparison_source": None, "state": "expired" if is_expired else ("valid" if expiry_date else "unavailable")})
    if is_expired:
        finding("expired-fire", "Fire safety certificate has expired", "attention", "Certificate validity",
                f"The submitted certificate expired on {expiry_date.strftime('%d %B %Y')}, {(review_date - expiry_date).days} days before the assessment date. Renewal evidence needs review.",
                expiry, "Valid evidence as at " + review_date.strftime("%d %B %Y"), expiry_src,
                "DEMO-VALIDITY-03", "Request a current fire safety certificate and check the replacement evidence.")
    elif expiry_date is None:
        finding("fire-date-unreadable", "Fire certificate date needs confirmation", "review", "Certificate validity",
                "A valid date could not be extracted. An unreadable value is not treated as an expired certificate.", expiry or "No readable validity date",
                "Readable validity date", expiry_src, "DEMO-VALIDITY-03", "Read the source certificate manually and record its validity date.")
    checks.append({"id": "fire-validity", "label": "Certificate validity", "result": "attention" if is_expired else ("pass" if expiry_date else "pending"),
                   "detail": f"Fire certificate expired {expiry}; assessment date {review_date.isoformat()}." if is_expired else (f"Certificate remains valid on {review_date.isoformat()}." if expiry_date else "Date unreadable; manual confirmation required.")})

    faculty_id, faculty_src = field(pages_by_id, "faculty", ["Institution ID", "Permanent Institution ID"])
    id_mismatch = faculty_id is not None and app_id is not None and faculty_id != app_id
    facts.append({"key": "faculty_institution_id", "label": "Faculty return identifier", "current": faculty_id, "previous": app_id,
                  "changed": False, "source": faculty_src, "comparison_source": app_id_src, "state": "mismatch" if id_mismatch else ("consistent" if faculty_id and app_id else "unavailable")})
    if id_mismatch:
        finding("id-mismatch", "Institution ID differs in the faculty return", "attention", "Cross-document consistency",
                "The institution identifier on the faculty return differs from the current application. A clerical error is possible; the mismatch alone does not establish misconduct.",
                faculty_id, app_id, faculty_src, "DEMO-IDENTITY-04", "Request the corrected faculty return or a documented explanation for the identifier difference.", app_id_src)
    checks.append({"id": "identity", "label": "Cross-document identity", "result": "attention" if id_mismatch else ("pass" if faculty_id and app_id and app_id == (reg_id or prior_id) else "pending"),
                   "detail": f"Faculty return: {faculty_id}; application: {app_id}." if faculty_id and app_id else "An identifier could not be read; manual confirmation is required."})

    occupancy_reference, occupancy_src = field(pages_by_id, "occupancy", ["Certificate number", "Certificate No.", "Reference number", "Certificate reference"])
    occupancy_finding = finding("source-unavailable", "Occupancy record awaits source confirmation", "review", "Source verification",
            "The document has been read locally. Its issuing-authority record has not yet been checked. Use the source verification step to run the clearly labelled simulation.",
            occupancy_reference or "Submitted occupancy certificate", "Issuing-authority confirmation", occupancy_src,
            "DEMO-SOURCE-05", "Run source verification; if unavailable, record a manual verification task.")
    occupancy_finding["verification"] = {"status": "not_attempted", "simulated": True, "source": "Demo municipal occupancy register", "timestamp": None}
    checks.append({"id": "occupancy-source", "label": "Occupancy source confirmation", "result": "pending", "detail": "Not yet attempted. Source adapter is a labelled simulation."})
    payment_ref, payment_src = field(pages_by_id, "payment", ["Receipt number", "Receipt reference", "Transaction reference", "Payment reference", "Transaction ID"])
    facts.append({"key": "payment_reference", "label": "Payment receipt reference", "current": payment_ref, "previous": None,
                  "changed": False, "source": payment_src, "comparison_source": None, "state": "recorded" if payment_ref else "unavailable"})
    checks.append({"id": "payment-source", "label": "Receipt record comparison", "result": "pending", "detail": "Receipt read; explicit simulated source check is available."})
    return {"facts": facts, "findings": findings, "checks": checks,
            "summary": {"documents_read": len(documents) - len(missing), "pages_read": sum(len(p) for p in pages_by_id.values()),
                        "findings": len(findings), "changed_facts": sum(1 for f in facts if f.get("changed")),
                        "mandatory_checks": 5, "change_triggered_checks": int(changed_intake), "open_findings": len(findings)},
            "extraction_method": "Native PDF text extraction (pypdf); no OCR model used in this build",
            "rules_method": "Deterministic comparisons using versioned demonstration rules",
            "rule_version": "DEMO-2026.1", "review_date": review_date.isoformat(), "run_at": now(), "verifications": {}}


class CaseStore:
    def __init__(self, root: Path = ROOT, db_path: Path | None = None):
        self.root = Path(root)
        self.lock = threading.RLock()
        self.db_path = Path(db_path) if db_path else self.root / "runtime" / "case.sqlite3"
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.db_path) as db:
            db.execute("CREATE TABLE IF NOT EXISTS state (id INTEGER PRIMARY KEY CHECK(id=1), payload TEXT NOT NULL)")
        if self._read() is None:
            self._write(self._new())

    def _new(self) -> dict[str, Any]:
        manifest = load_manifest(self.root)
        return {"id": manifest.get("id", "EOA/2026/0142"), "institution": "Deccan Institute of Technology", "institution_id": "1-300701",
                "academic_year": manifest.get("academic_year", "2026–27"), "application_type": manifest.get("application_type", "Extension of Approval"), "status": "Ready for pre-scrutiny",
                "review_date": REVIEW_DATE.isoformat(), "reviewer": "A. Rao", "rule_version": "DEMO-2026.1",
                "analysis": None, "events": [{"id": str(uuid.uuid4()), "timestamp": now(), "actor": "Local prototype", "action": "case_created",
                                              "detail": "Synthetic application and source documents loaded for local demonstration."}], "requests": [], "revisions": [],
                "capabilities": {"native_pdf_extraction": True, "ocr": False, "external_verification": "simulated",
                                 "authentication": "local demonstration reviewer", "persistence": "SQLite on this computer",
                                 "final_regulatory_decision": False}}

    def _read(self) -> dict[str, Any] | None:
        with sqlite3.connect(self.db_path) as db:
            row = db.execute("SELECT payload FROM state WHERE id=1").fetchone()
        return json.loads(row[0]) if row else None

    def _write(self, state: dict[str, Any]):
        with sqlite3.connect(self.db_path) as db:
            db.execute("INSERT INTO state(id,payload) VALUES(1,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload", (json.dumps(state),))

    def case(self) -> dict[str, Any]:
        state = self._read()
        state["documents"] = load_manifest(self.root)["documents"]
        state.setdefault("revisions", [])
        for revision in state["revisions"]:
            if not any(d["id"] == revision["replacement_document"]["id"] for d in state["documents"]):
                state["documents"].append(revision["replacement_document"])
        state.setdefault("recommendations", [])
        state["risk"] = self.risk(state)
        return state

    @staticmethod
    def risk(state: dict) -> dict:
        """Counts of review obligations, not a probabilistic fraud/risk score."""
        analysis = state.get("analysis")
        if not analysis:
            return {"assessed": False, "blocker_count": 1, "unreviewed_findings": 0, "unresolved_verifications": 0,
                    "pending_requests": 0, "ready_for_authority": False,
                    "blockers": [{"id": "analysis-required", "reason": "Run preliminary scrutiny before recommending case movement."}]}
        findings = analysis["findings"]
        blockers = []
        for item in findings:
            reason = None
            if item.get("resolution", {}).get("status") == "pending_officer_verification":
                reason = "Replacement evidence still requires officer review."
            elif item["status"] == "open":
                reason = "The observation has not been reviewed."
            elif item["status"] == "rectification_requested":
                reason = "Rectification remains outstanding."
            elif item["status"] == "inspection_advised":
                reason = "Recommended inspection has not been completed."
            elif item["status"] == "confirmed" and item["id"] in {"expired-fire", "id-mismatch"} and not item.get("resolution"):
                reason = "The officer confirmed the issue; corrective evidence is still required."
            if reason:
                blockers.append({"id": "finding:" + item["id"], "finding_id": item["id"], "reason": reason})
        source_checks = [c for c in analysis["checks"] if c["id"].endswith("-source") and c["result"] != "pass"]
        for check in source_checks:
            blockers.append({"id": "check:" + check["id"], "check_id": check["id"], "reason": check["detail"]})
        for check in analysis["checks"]:
            if check["result"] == "pending" and not check["id"].endswith("-source"):
                blockers.append({"id": "check:" + check["id"], "check_id": check["id"], "reason": check["detail"]})
        pending_requests = [r for r in state["requests"] if r["status"] in {"Awaiting institution response", "Response received; officer review pending"}]
        return {"assessed": True, "blocker_count": len(blockers), "unreviewed_findings": sum(f["status"] == "open" for f in findings),
                "unresolved_verifications": len(source_checks), "pending_requests": len(pending_requests),
                "ready_for_authority": not blockers and not pending_requests, "blockers": blockers,
                "meaning": "Counts of outstanding review obligations; not an authenticity verdict or a fraud probability."}

    def requirements(self) -> dict:
        case = self.case()
        rows = []
        for document in load_manifest(self.root)["documents"]:
            try:
                readable = any(p["text"].strip() for p in self.evidence(document["id"])["pages"])
            except (FileNotFoundError, ValueError):
                readable = False
            rows.append({"document_id": document["id"], "title": document["title"], "required": True,
                         "readable": readable, "status": "Readable evidence present" if readable else "Readable evidence required"})
        rules = load_rules(self.root)
        return {"application_type": "Extension of Approval", "supported_categories": ["Extension of Approval"], "illustrative": True,
                "rule_version": case["rule_version"], "documents": rows,
                "mandatory_rules": [r for r in rules if r["scope"] == "Mandatory baseline check"],
                "change_triggered_rules": [r for r in rules if r["scope"] != "Mandatory baseline check"],
                "notice": "This is the seven-document synthetic EoA demonstration checklist, not an official AICTE document checklist. No other application category is implemented."}

    def evidence_graph(self) -> dict:
        case = self.case()
        nodes, edges, ids = [], [], set()
        def node(identifier, kind, label, **data):
            if identifier not in ids:
                nodes.append({"id": identifier, "type": kind, "label": label, **data})
                ids.add(identifier)
            return identifier
        def link(start, end, label):
            edge = {"from": start, "to": end, "label": label}
            if edge not in edges:
                edges.append(edge)
        def source_node(source):
            if not source:
                return None
            digest = hashlib.sha256(source["quote"].encode()).hexdigest()[:12]
            identifier = f"source:{source['document_id']}:{source['page']}:{digest}"
            return node(identifier, "source", f"{source['document_id']} · page {source['page']}", **source)
        case_node = node("case:" + case["id"], "case", case["id"], institution=case["institution"])
        for finding in (case.get("analysis") or {}).get("findings", []):
            fnode = node("finding:" + finding["id"], "finding", finding["title"], status=finding["status"], severity=finding["severity"])
            link(case_node, fnode, "contains finding")
            for field_name, label in [("source", "supported by"), ("comparison_source", "compared with")]:
                snode = source_node(finding.get(field_name))
                if snode:
                    link(fnode, snode, label)
            old_source = source_node(finding.get("original_evidence", {}).get("source"))
            if old_source:
                link(fnode, old_source, "retains original evidence")
            rule = finding["rule"]
            rnode = node("rule:" + rule["id"], "rule", rule["title"], rule_id=rule["id"], version=rule["version"], description=rule["description"], illustrative=True)
            link(fnode, rnode, "evaluated against")
            verification = finding.get("verification")
            if verification:
                vnode = node("verification:" + finding["id"], "verification", verification["source"], **verification)
                link(fnode, vnode, "source check")
        for event in case["events"]:
            finding_node = "finding:" + event.get("finding_id", "")
            if event["action"].startswith("officer_") and finding_node in ids:
                anode = node("action:" + event["id"], "officer_action", event["action"].replace("officer_", "").replace("_", " "),
                             actor=event["actor"], timestamp=event["timestamp"], reason=event["detail"])
                link(finding_node, anode, "reviewed through")
        return {"case_id": case["id"], "nodes": nodes, "edges": edges, "risk": case["risk"],
                "notice": "Graph links are derived from this case's extracted evidence, illustrative rules and recorded officer actions."}

    def rule_preview(self, rule_id: str, changes: dict) -> dict:
        rules = load_rules(self.root)
        rule = next((r for r in rules if r["id"] == rule_id), None)
        if rule is None:
            raise ValueError("Unknown demonstration rule.")
        if not isinstance(changes, dict) or not changes or any(k not in {"title", "description", "review_date"} for k in changes):
            raise ValueError("Preview supports title, description and (for DEMO-VALIDITY-03 only) review_date. Baseline checks cannot be disabled.")
        proposed = dict(rule)
        for key in {"title", "description"} & changes.keys():
            value = changes[key]
            if not isinstance(value, str) or not 3 <= len(value.strip()) <= 1000:
                raise ValueError("Rule title/description must contain 3–1,000 characters.")
            proposed[key] = value.strip()
        case = self.case()
        current_date = date.fromisoformat(case["review_date"])
        proposed_date = current_date
        if "review_date" in changes:
            if rule_id != "DEMO-VALIDITY-03":
                raise ValueError("Assessment-date preview is supported only for the certificate-validity rule.")
            try:
                proposed_date = date.fromisoformat(changes["review_date"])
            except (TypeError, ValueError) as exc:
                raise ValueError("review_date must be a valid ISO date, for example 2026-09-01.") from exc
        rule_check = {"DEMO-CHECK-01": "completeness", "DEMO-INTAKE-02": "intake", "DEMO-VALIDITY-03": "fire-validity", "DEMO-IDENTITY-04": "identity", "DEMO-SOURCE-05": "occupancy-source", "DEMO-PAYMENT-06": "payment-source"}
        documents = load_manifest(self.root)["documents"]
        pages = {}
        for doc in documents:
            try:
                pages[doc["id"]] = self.evidence(doc["id"])["pages"]
            except (ValueError, FileNotFoundError):
                pages[doc["id"]] = []
        effective_fire_id = "fire"
        for revision in case["revisions"]:
            if revision["original_document_id"] == "fire":
                effective_fire_id = revision["replacement_document"]["id"]
                pages["fire"] = self.evidence(effective_fire_id)["pages"]
        before = analyse_documents(documents, pages, rules, current_date)
        after = analyse_documents(documents, pages, rules, proposed_date)
        def outcome(result):
            found = [f for f in result["findings"] if f["rule"]["id"] == rule_id]
            if effective_fire_id != "fire" and rule_id == "DEMO-VALIDITY-03":
                for f in found:
                    if f.get("source"):
                        f["source"]["document_id"] = effective_fire_id
            return {"check": next(c for c in result["checks"] if c["id"] == rule_check[rule_id]), "findings": found, "finding_count": len(found)}
        return {"dry_run": True, "persisted": False, "rule_id": rule_id, "current": rule, "proposed": proposed,
                "current_review_date": current_date.isoformat(), "proposed_review_date": proposed_date.isoformat(),
                "current_outcome": outcome(before), "proposed_outcome": outcome(after), "effective_fire_document_id": effective_fire_id,
                "notice": "Preview only. Assessment date is a what-if parameter. Description/title edits are metadata and do not change executable logic. Existing case, rules and officer actions are unchanged."}

    def decision(self, decision: str, note: str) -> dict:
        labels = {"inspection_required": "Inspection recommended to authority", "ready_for_authority": "Ready for competent-authority consideration", "return_for_rectification": "Return for rectification recommended"}
        if decision not in labels:
            raise ValueError("Choose inspection_required, ready_for_authority or return_for_rectification. No approval/rejection endpoint exists.")
        if not isinstance(note, str) or not 10 <= len(note.strip()) <= 2000:
            raise ValueError("Record a recommendation reason between 10 and 2,000 characters.")
        with self.lock:
            state = self._read()
            if not state["analysis"]:
                raise ValueError("Run pre-scrutiny before recording an officer recommendation.")
            risk = self.risk(state)
            if decision == "ready_for_authority" and not risk["ready_for_authority"]:
                raise ValueError(f"Cannot mark ready for authority: {risk['blocker_count']} unresolved review obligations and {risk['pending_requests']} pending response tasks remain. See case.risk.blockers.")
            existing = state.get("recommendation")
            if existing and existing["decision"] == decision and existing["note"] == note.strip() and existing["risk_snapshot"] == risk:
                return self.case()
            recommendation = {"id": "REC-" + str(len(state.setdefault("recommendations", [])) + 1).zfill(3), "decision": decision,
                              "label": labels[decision], "note": note.strip(), "reviewer": state["reviewer"], "timestamp": now(),
                              "risk_snapshot": risk, "is_final_decision": False, "delivery": "Local recommendation only; nothing sent to AICTE"}
            state["recommendations"].append(recommendation)
            state["recommendation"] = recommendation
            state["status"] = labels[decision]
            self._event(state, "officer_recommendation", f"{labels[decision]}. {note.strip()}", actor=state["reviewer"], recommendation_id=recommendation["id"], decision=decision)
            self._write(state)
            return self.case()

    def upload(self, filename: str, content_base64: str) -> dict:
        """Inspect an uploaded PDF in memory; do not auto-assign it to the case."""
        if not isinstance(filename, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9 _.-]{0,119}\.pdf", filename, flags=re.I) or ".." in filename:
            raise ValueError("Use a simple PDF filename without directory separators, traversal or special characters (maximum 124 characters).")
        if not isinstance(content_base64, str) or len(content_base64) > 7 * 1024 * 1024:
            raise ValueError("Provide a base64 PDF no larger than 5 MB.")
        try:
            body = base64.b64decode(content_base64, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise ValueError("The uploaded content is not valid base64.") from exc
        if not body or len(body) > 5 * 1024 * 1024:
            raise ValueError("The uploaded PDF must be between 1 byte and 5 MB.")
        if not body.startswith(b"%PDF-"):
            raise ValueError("The supplied file does not have a PDF header.")
        from pypdf import PdfReader
        try:
            reader = PdfReader(io.BytesIO(body), strict=True)
            if reader.is_encrypted:
                raise ValueError("Encrypted PDFs cannot be inspected in this local demonstration.")
            if len(reader.pages) > 40:
                raise ValueError("The supplementary PDF is limited to 40 pages.")
            extracted = [{"page": i + 1, "text": (p.extract_text() or "")[:50000]} for i, p in enumerate(reader.pages)]
        except Exception as exc:
            raise ValueError("The PDF could not be read safely: " + str(exc)[:180]) from exc
        digest = hashlib.sha256(body).hexdigest()
        manifest = load_manifest(self.root)
        duplicates = []
        for doc in manifest["documents"] + manifest.get("replacement_documents", []):
            path = self.root / "documents" / Path(doc["filename"]).name
            if path.is_file() and hashlib.sha256(path.read_bytes()).hexdigest() == digest:
                duplicates.append({"document_id": doc["id"], "title": doc["title"], "filename": doc["filename"]})
        fields = []
        for key, labels in [("institution_id", ["Institution ID"]), ("requested_intake", ["Requested intake"]), ("approved_intake", ["Approved intake"]), ("valid_until", ["Valid until", "Expiry date"]), ("certificate_reference", ["Certificate reference", "Certificate number"]), ("receipt_reference", ["Receipt reference", "Receipt number"])]:
            value, source = field({"supplementary": extracted}, "supplementary", labels)
            if value is not None:
                fields.append({"key": key, "value": value, "source": source})
        return {"filename": filename, "bytes": len(body), "sha256": digest, "pages": extracted, "fields": fields,
                "readable": any(p["text"].strip() for p in extracted), "duplicate_matches": duplicates,
                "status": "supplementary_only", "case_assigned": False, "persisted": False, "category": None,
                "method": "Native PDF text extraction and exact SHA-256 comparison",
                "notice": "Inspected in memory only. Not assigned to a document category, not added to the case and not authenticated. Exact file duplicates are detected; altered-image/forensic detection and OCR are not implemented."}

    def _event(self, state: dict, action: str, detail: str, actor: str = "Local validation service", **extra):
        state["events"].append({"id": str(uuid.uuid4()), "timestamp": now(), "actor": actor, "action": action, "detail": detail, **extra})

    def document(self, document_id: str) -> dict:
        manifest = load_manifest(self.root)
        result = next((d for d in manifest["documents"] + manifest.get("replacement_documents", []) if d["id"] == document_id), None)
        if result is None:
            raise ValueError("Unknown document identifier.")
        return result

    def evidence(self, document_id: str) -> dict:
        doc = self.document(document_id)
        path = self.root / "documents" / Path(doc["filename"]).name
        if not path.is_file():
            raise FileNotFoundError("Document file has not been generated yet.")
        return {"document_id": document_id, "title": doc["title"], "method": "pypdf native text extraction", "pages": extract_pages(path)}

    def analyse(self) -> dict:
        with self.lock:
            state = self._read()
            if state["analysis"] is not None:
                # Re-opening the result must not discard an officer's decisions.
                return self.case()
            documents = load_manifest(self.root)["documents"]
            pages = {}
            for doc in documents:
                try:
                    pages[doc["id"]] = self.evidence(doc["id"])["pages"]
                except (FileNotFoundError, ValueError):
                    pages[doc["id"]] = []
            state["analysis"] = analyse_documents(documents, pages, load_rules(self.root))
            state["status"] = "Officer review required"
            self._event(state, "analysis_completed", f"Read {state['analysis']['summary']['pages_read']} PDF pages and produced {len(state['analysis']['findings'])} evidence-linked observations. No regulatory decision was made.")
            self._write(state)
            return self.case()

    def verify(self, document_id: str) -> dict:
        if document_id not in {"occupancy", "payment", "fire"}:
            raise ValueError("A demonstration source adapter is available only for occupancy, payment and fire documents.")
        with self.lock:
            state = self._read()
            if not state["analysis"]:
                raise ValueError("Run pre-scrutiny before source verification.")
            analysis = state["analysis"]
            if document_id in analysis["verifications"]:
                return self.case()
            timestamp = now()
            if document_id == "occupancy":
                result = {"status": "unavailable", "simulated": True, "source": "Demo municipal occupancy register",
                          "timestamp": timestamp, "detail": "Simulated authority timeout. No live portal contacted. Manual verification remains required.", "reference": "SIM-OCC-2026-0142"}
                for finding in analysis["findings"]:
                    if finding["id"] == "source-unavailable":
                        finding.update({"title": "Occupancy authority unavailable", "summary": "The simulated issuing-authority request timed out. Source availability does not determine whether the certificate is valid.",
                                        "observed": "Source unavailable", "next_action": "Assign manual confirmation of the occupancy certificate; retain the submitted evidence.", "verification": result})
                for check in analysis["checks"]:
                    if check["id"] == "occupancy-source":
                        check.update({"result": "pending", "detail": "Simulated authority timeout; manual verification required. No rejection."})
            elif document_id == "payment":
                source = next((f for f in analysis["facts"] if f["key"] == "payment_reference"), {})
                ref = source.get("current")
                # Exact fixture reference supplied by the synthetic document producer.
                # The extracted value is compared with a fixture; it is not trusted
                # merely because it was read from a PDF.
                fixture = load_manifest(self.root).get("verification_fixtures", {}).get("payment", {})
                expected = fixture.get("receipt_reference", "DEMO-PAY-8831")
                evidence = self.evidence("payment")["pages"]
                payment_id, _ = field({"payment": evidence}, "payment", ["Institution ID"])
                amount, _ = field({"payment": evidence}, "payment", ["Amount"])
                matched = bool(ref) and ref == expected and payment_id == "1-300701" and integer(amount) == 10000
                result = {"status": "matched" if matched else "manual_review", "simulated": True, "source": "Demo payment ledger",
                          "timestamp": timestamp, "reference": ref, "expected_reference": expected, "institution_id": payment_id, "amount": amount,
                          "detail": "Extracted receipt reference, institution ID and amount match the synthetic payment ledger." if matched else "Receipt fields do not match the synthetic fixture; manual review is required."}
                for check in analysis["checks"]:
                    if check["id"] == "payment-source":
                        check.update({"result": "pass" if matched else "attention", "detail": result["detail"] + " Simulated source."})
            else:
                fire_ref, _ = field({"fire": self.evidence("fire")["pages"]}, "fire", ["Certificate reference"])
                matched = fire_ref == "DEMO-FS-087"
                result = {"status": "matched" if matched else "manual_review", "simulated": True, "source": "Demo fire-service issuance register", "timestamp": timestamp,
                          "reference": fire_ref, "expected_reference": "DEMO-FS-087",
                          "detail": "Synthetic issuance record found. Issuance confirmation does not renew the expired certificate." if matched else "Reference did not match the synthetic issuance record; manual review is required."}
                for finding in analysis["findings"]:
                    if finding["id"] == "expired-fire" and (finding.get("source") or {}).get("document_id") == "fire":
                        finding["verification"] = result
            analysis["verifications"][document_id] = result
            self._event(state, "source_verification", f"{result['source']}: {result['status']}. {result['detail']}", document_id=document_id, simulated=True)
            self._write(state)
            return self.case()

    def action(self, finding_id: str, action: str, note: str) -> dict:
        if action not in {"confirm", "rectify", "override", "inspect"}:
            raise ValueError("Supported actions are confirm, rectify, override and inspect.")
        if not isinstance(note, str) or len(note.strip()) < 10 or len(note.strip()) > 2000:
            raise ValueError("Record a reason or instruction between 10 and 2,000 characters.")
        with self.lock:
            state = self._read()
            if not state["analysis"]:
                raise ValueError("Run pre-scrutiny before recording an officer action.")
            finding = next((f for f in state["analysis"]["findings"] if f["id"] == finding_id), None)
            if finding is None:
                raise ValueError("Unknown finding identifier.")
            if action == "inspect" and finding_id not in {"source-unavailable", "intake-change"}:
                raise ValueError("Inspection recommendations apply to occupancy or intake-capacity evidence in this demonstration.")
            status = {"confirm": "confirmed", "rectify": "rectification_requested", "override": "overridden", "inspect": "inspection_advised"}[action]
            if finding["status"] == status and finding.get("officer_note") == note.strip():
                return self.case()
            finding.update({"status": status, "officer_note": note.strip(), "reviewed_at": now(), "reviewed_by": state["reviewer"]})
            if action == "confirm" and finding.get("resolution"):
                finding["resolution"].update({"status": "officer_confirmed", "reviewed_at": now(), "reviewed_by": state["reviewer"]})
                finding.update({"title": "Replacement fire certificate reviewed by officer",
                                "summary": f"The replacement date and institution ID passed the demonstration checks, and {state['reviewer']} recorded a review reason. This is a local officer review, not a live issuing-authority authentication or application approval.",
                                "next_action": "Retain both certificate versions and complete the other outstanding case checks before authority consideration."})
                for fact in state["analysis"]["facts"]:
                    if fact["key"] == "valid_until":
                        fact["state"] = "valid_reviewed"
                for check in state["analysis"]["checks"]:
                    if check["id"] == "fire-validity":
                        check["detail"] = f"Replacement date check passed; {state['reviewer']} recorded a review of the replacement evidence. No live issuer authentication."
                for revision in state.get("revisions", []):
                    if revision["id"] == finding["resolution"]["revision_id"]:
                        revision.update({"officer_verification": "confirmed", "reviewed_at": now(), "reviewed_by": state["reviewer"]})
                for request in state["requests"]:
                    if request.get("revision_id") == finding["resolution"]["revision_id"]:
                        request["status"] = "Response reviewed by officer"
                state["status"] = "Officer review in progress"
            if action == "inspect":
                state["status"] = "Inspection recommended"
            if action == "rectify":
                state["requests"].append({"id": "RQ-" + str(len(state["requests"]) + 1).zfill(3), "finding_id": finding_id,
                                          "title": finding["title"], "note": note.strip(), "status": "Awaiting institution response",
                                          "timestamp": now(), "delivery": "Local record only; no message sent"})
                state["status"] = "Rectification requested"
            state["analysis"]["summary"]["open_findings"] = sum(f["status"] == "open" for f in state["analysis"]["findings"])
            self._event(state, "officer_" + action, note.strip(), actor=state["reviewer"], finding_id=finding_id, finding_title=finding["title"], rule_version=finding["rule"]["version"])
            self._write(state)
            return self.case()

    def resubmit(self, finding_id: str, document_id: str, replacement: str, note: str) -> dict:
        """Accept only the supplied renewal fixture and re-read its real PDF text.

        Original documents and findings are preserved. Passing a date comparison
        resolves that check only; the officer must still verify the replacement.
        """
        if (finding_id, document_id, replacement) != ("expired-fire", "fire", "fire-renewed.pdf"):
            raise ValueError("The demonstration supports the supplied fire-renewed.pdf replacement for the fire-certificate observation only.")
        if not isinstance(note, str) or not 10 <= len(note.strip()) <= 2000:
            raise ValueError("Provide an institutional response between 10 and 2,000 characters.")
        with self.lock:
            state = self._read()
            if not state["analysis"]:
                raise ValueError("Run pre-scrutiny and request rectification before submitting replacement evidence.")
            revisions = state.setdefault("revisions", [])
            if any(r["finding_id"] == finding_id and r["replacement_document"]["filename"] == replacement for r in revisions):
                return self.case()
            finding = next((f for f in state["analysis"]["findings"] if f["id"] == finding_id), None)
            request = next((r for r in reversed(state["requests"]) if r["finding_id"] == finding_id and r["status"] == "Awaiting institution response"), None)
            if finding is None or finding["status"] != "rectification_requested" or request is None:
                raise ValueError("An open rectification request for the expired fire certificate is required before resubmission.")
            manifest = load_manifest(self.root)
            replacement_doc = next((d for d in manifest.get("replacement_documents", []) if d["filename"] == replacement), None)
            if replacement_doc is None:
                raise ValueError("The configured replacement evidence is unavailable.")
            pages = self.evidence(replacement_doc["id"])["pages"]
            extracted, source = field({replacement_doc["id"]: pages}, replacement_doc["id"], ["Valid until", "Expiry date"])
            institution_id, _ = field({replacement_doc["id"]: pages}, replacement_doc["id"], ["Institution ID"])
            expiry = parsed_date(extracted)
            passed = bool(expiry and expiry >= REVIEW_DATE and institution_id == state["institution_id"])
            timestamp = now()
            original_evidence = {key: finding.get(key) for key in ("source", "observed", "expected", "summary", "title", "verification")}
            revision = {"id": "REV-" + str(len(revisions) + 1).zfill(3), "finding_id": finding_id, "original_document_id": document_id,
                        "replacement_document": replacement_doc, "timestamp": timestamp, "note": note.strip(),
                        "source": source, "extracted_valid_until": extracted, "rule_id": "DEMO-VALIDITY-03", "rule_version": "DEMO-2026.1",
                        "result": "date_check_passed" if passed else "review_required", "officer_verification": "pending"}
            revisions.append(revision)
            finding["original_evidence"] = original_evidence
            finding["resolution"] = {"status": "pending_officer_verification", "date_check": "pass" if passed else "attention",
                                     "source": source, "timestamp": timestamp, "revision_id": revision["id"], "institution_response": note.strip()}
            if passed:
                finding.update({"status": "resolved", "title": "Replacement fire certificate requires officer verification",
                                "summary": f"The replacement PDF states validity until {extracted}. Its date and institution ID pass the demonstration checks. Officer verification remains pending; no application approval has been issued.",
                                "observed": extracted, "source": source, "verification": None,
                                "officer_note": None, "reviewed_at": None, "reviewed_by": None,
                                "next_action": "Inspect the replacement certificate and confirm the finding with a recorded reason. The original remains in the file."})
            else:
                finding.update({"status": "open", "title": "Replacement fire certificate still requires rectification",
                                "summary": "The replacement date or institution identifier did not pass the recheck; manual scrutiny remains required.",
                                "observed": extracted or "Unreadable date", "source": source,
                                "next_action": "Review the replacement document and request further correction."})
            for fact in state["analysis"]["facts"]:
                if fact["key"] == "valid_until":
                    fact.update({"original_source": fact["source"], "original_value": fact["current"], "current": extracted,
                                 "source": source, "state": "valid_pending_review" if passed else "review"})
            for check in state["analysis"]["checks"]:
                if check["id"] == "fire-validity":
                    check.update({"result": "pass" if passed else "attention", "detail": f"Replacement document date: {extracted or 'unreadable'}. Officer verification remains pending."})
            state["analysis"]["summary"]["open_findings"] = sum(f["status"] == "open" for f in state["analysis"]["findings"])
            state["analysis"]["summary"]["replacement_documents_read"] = len(revisions)
            state["status"] = "Replacement evidence awaiting officer review"
            request.update({"status": "Response received; officer review pending", "response": note.strip(), "response_at": timestamp,
                            "replacement_document_id": replacement_doc["id"], "revision_id": revision["id"]})
            self._event(state, "replacement_received", f"Received {replacement_doc['title']}. {note.strip()}", actor="Synthetic institution response", finding_id=finding_id, document_id=replacement_doc["id"], revision_id=revision["id"])
            self._event(state, "expiry_rechecked", f"Read replacement PDF: valid until {extracted or 'unreadable'}. Date/identity check {'passed' if passed else 'requires review'}; officer verification pending.", finding_id=finding_id, rule_id="DEMO-VALIDITY-03", rule_version="DEMO-2026.1", revision_id=revision["id"])
            self._write(state)
            return self.case()

    def reset(self) -> dict:
        with self.lock:
            self._write(self._new())
            return self.case()
