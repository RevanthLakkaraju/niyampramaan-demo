"""Executable, illustrative change-control and rule-replay mechanisms."""
import copy
import uuid
from engine import now, analyse_documents, load_manifest, load_rules

DEFAULT={'version':'CAPACITY-DEMO-1','students_per_faculty':20,'require_lab':True,'require_classroom':True}
CONTROLS=[('permission','Intake-change permission','Application and permitted-change evidence'),('faculty','Faculty capacity','Complete faculty return'),('lab','Laboratory capacity','Laboratory capacity schedule'),('classroom','Classroom capacity','Classroom capacity schedule'),('infrastructure','Infrastructure evidence','Current building and occupancy evidence')]

def active(store):return store._read().get('capacity_rule',DEFAULT).copy()
def signature(store):
    c=store.case();a=c['analysis']
    if not a:
        docs=load_manifest(store.root)['documents'];a=analyse_documents(docs,{d['id']:store.evidence(d['id'])['pages'] for d in docs},load_rules(store.root))
    intake=next(x for x in a['facts'] if x['key']=='requested_intake');changed=intake['changed'];rule=active(store)
    controls=[{'id':key,'control':label,'document':document,'status':'Evidence review required','trigger':f"Intake {intake['previous']} → {intake['current']}", 'rule':rule['version']} for key,label,document in CONTROLS if changed and (key!='lab' or rule['require_lab']) and (key!='classroom' or rule['require_classroom'])]
    baseline=[{'id':x['id'],'label':x['label'],'result':x['result']} for x in a['checks'] if x['id']!='intake']
    # Only configured alternatives are compared. A route is not regulatory permission.
    common=[]
    for f in a['findings']:
        if f['id']=='expired-fire' and f.get('resolution',{}).get('status')!='officer_confirmed':common.append('Current fire-safety evidence and officer review')
        if f['id']=='id-mismatch' and f['status']!='overridden':common.append('Corrected faculty institution ID or accepted explanation')
        if f['id']=='source-unavailable':common.append('Occupancy confirmation or authorised inspection')
    alternatives=[]
    for key,label,documents,expected in [
        ('retain','Retain the requested intake', [x['document'] for x in controls], 'Capacity evidence ready for officer assessment; approval still pending'),
        ('revise','Request amendment to the previous intake', ['Revised application / withdrawal of increase request'] if changed else [],'Change-triggered capacity checks cease only after an accepted amendment; baseline checks remain')]:
        tasks=sorted(set(documents+common));alternatives.append({'id':key,'title':label,'tasks':tasks,'count':len(tasks),'expected':expected,'requires_permission':key=='revise'})
    return {'baseline':{'document':'Previous EoA specimen','value':intake['previous'],'source':intake['comparison_source'],'status':'Supplied baseline; no live authority verification'},'current':intake['current'],'changed':changed,'controls':controls,'mandatory':baseline,'rule':rule,'alternatives':alternatives,'smallest_option':min(alternatives,key=lambda x:x['count'])['id'],'affected_fields':['Requested intake','Faculty institution ID','Fire certificate validity','Occupancy verification'],'rerun':['Read revised evidence','Compare intake with baseline','Re-evaluate dependent capacity controls','Recheck dates and institutional identity','Retain source-confirmation obligations'],'notice':'Smallest task set among these configured alternatives, not a universal regulatory optimum. Amendment requires permission. Supporting evidence is assessed, never assumed compliant.'}

def cases(store):
    c=store.case();fact=next(x for x in c['analysis']['facts'] if x['key']=='requested_intake')
    return [{'id':c['id'],'category':'Extension of Approval','intake':fact['current'],'faculty':None,'lab':False,'classroom':False,'source':'Current case; full capacity evidence unverified'}, {'id':'REPLAY-SAMPLE-02','category':'Extension of Approval','intake':180,'faculty':9,'lab':True,'classroom':True,'source':'Synthetic replay fixture only'}, {'id':'REPLAY-SAMPLE-03','category':'Extension of Approval','intake':240,'faculty':10,'lab':False,'classroom':True,'source':'Synthetic replay fixture only'}]
def outcomes(case,rule):
    result=[]
    if case['faculty'] is None:result.append('Faculty capacity requires evidence')
    elif case['intake']>case['faculty']*rule['students_per_faculty']:result.append('Declared faculty capacity below illustrative threshold')
    if rule['require_lab'] and not case['lab']:result.append('Laboratory evidence requires review')
    if rule['require_classroom'] and not case['classroom']:result.append('Classroom evidence requires review')
    return result

def replay(store,payload):
    ratio=payload.get('students_per_faculty');lab=payload.get('require_lab');room=payload.get('require_classroom')
    if type(ratio)!=int or not 1<=ratio<=100 or type(lab)!=bool or type(room)!=bool:raise ValueError('Use a faculty parameter between 1 and 100 and explicit evidence requirements.')
    store.analyse()
    with store.lock:
        state=store._read();before=active(store);proposed={'version':'CAPACITY-DEMO-'+uuid.uuid4().hex[:6].upper(),'students_per_faculty':ratio,'require_lab':lab,'require_classroom':room}
        rows=[]
        for case in cases(store):
            old=outcomes(case,before);new=outcomes(case,proposed)
            rows.append({**case,'before':old,'after':new,'created':sorted(set(new)-set(old)),'resolved':sorted(set(old)-set(new))})
        report={'id':'REPLAY-'+uuid.uuid4().hex[:8],'active':before,'proposed':proposed,'rows':rows,'status':'Awaiting reviewer authorisation','timestamp':now(),'notice':'Three local pending-case scenarios, including two synthetic fixtures. Parameters illustrate the mechanism and are not AICTE requirements.'}
        state['rule_replay']=report;store._event(state,'rule_impact_replay','Candidate capacity rule replayed on three local pending-case scenarios. Active rule unchanged.',actor=state['reviewer']);store._write(state);return report

def activate(store,payload):
    note=str(payload.get('note','')).strip()
    if len(note)<10:raise ValueError('Record the basis for local rule activation.')
    with store.lock:
        state=store._read();report=state.get('rule_replay')
        if not report or report['id']!=payload.get('replay_id') or report['status']!='Awaiting reviewer authorisation':raise ValueError('Replay the candidate before authorising activation.')
        if report['active']!=active(store):raise ValueError('The active rule changed; replay again.')
        state['capacity_rule']=copy.deepcopy(report['proposed']);report.update(status='Activated locally',authorised_by=state['reviewer'],note=note,activated_at=now())
        store._event(state,'capacity_rule_activated',note,actor=state['reviewer'],rule_version=report['proposed']['version']);store._write(state);return report
