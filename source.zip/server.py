#!/usr/bin/env python3
"""Serve the local synthetic case at http://127.0.0.1:4186."""
from __future__ import annotations

import argparse
import os
import tempfile
import secrets
import threading
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import sys
from http.cookies import SimpleCookie
from portal import Sessions, Portal, ACCOUNTS
import scrutiny
import copy
from urllib.parse import unquote, urlparse

from engine import CaseStore, ROOT, load_rules


class VisitorCases:
    """Separate ephemeral case, login sessions and walkthrough for each browser."""
    def __init__(self):
        self.lock = threading.RLock()
        self.items = {}
        self.directory = Path(tempfile.mkdtemp(prefix='niyampramaan-visitors-'))
    def get(self, token):
        with self.lock:
            if token in self.items:
                return token, self.items[token], False
            if len(self.items) >= 200:
                raise ValueError('The demo is at capacity. Please try again after the service restarts.')
            token = secrets.token_urlsafe(32)
            pair = (CaseStore(db_path=self.directory / token / 'case.sqlite3'), Sessions())
            self.items[token] = pair
            return token, pair, True

visitors = VisitorCases()


class Handler(SimpleHTTPRequestHandler):
    server_version = "NiyamPramaanLocal/1.0"

    def __init__(self, *args, store: CaseStore, sessions: Sessions, **kwargs):
        self.store = store
        self.sessions = sessions
        self.portal = Portal(store)
        super().__init__(*args, directory=str(ROOT / "public"), **kwargs)

    def parse_request(self):
        if not super().parse_request(): return False
        cookie = SimpleCookie()
        try: cookie.load(self.headers.get('Cookie', ''))
        except Exception: pass
        token = cookie['np_visitor'].value if 'np_visitor' in cookie else ''
        try:
            token, pair, fresh = visitors.get(token)
        except ValueError as error:
            self.send_error(503, str(error)); return False
        self.store, self.sessions = pair
        self.portal = Portal(self.store)
        self.visitor_cookie = token if fresh else None
        return True

    def end_headers(self):
        if getattr(self, "visitor_cookie", None):
            secure = "; Secure" if os.environ.get("RENDER") else ""
            self.send_header("Set-Cookie", f"np_visitor={self.visitor_cookie}; HttpOnly; SameSite=Strict; Path=/" + secure)
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def session(self):
        cookie = SimpleCookie()
        try: cookie.load(self.headers.get("Cookie", ""))
        except Exception: return None, ""
        token = cookie["np_session"].value if "np_session" in cookie else ""
        return self.sessions.get(token), token

    def json_response(self, value, status=200, download=False, cookie=None):
        body = json.dumps(value, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        if cookie is not None:
            self.send_header("Set-Cookie", cookie + ("; Secure" if os.environ.get("RENDER") else ""))
        if download:
            self.send_header("Content-Disposition", 'attachment; filename="NiyamPramaan-EOA-2026-0142-' + ('acknowledgement' if urlparse(self.path).path=='/api/acknowledgement' else 'dossier') + '.json"')
        self.end_headers()
        self.wfile.write(body)

    def safe_file(self, directory: Path, relative: str):
        root = directory.resolve()
        target = (root / unquote(relative)).resolve()
        if root not in target.parents or not target.is_file():
            self.send_error(404)
            return
        body = target.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", self.guess_type(str(target)))
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = urlparse(self.path).path
        try:
            identity, _ = self.session()
            if path == "/api/session":
                return self.json_response({"identity": identity})
            if path == "/api/health":
                return self.json_response({"ok": True, "mode": "local", "external_connections": False})
            if (path.startswith("/api/") or path.startswith("/documents/")) and not identity:
                return self.json_response({"error": "Sign in to a demonstration portal."}, 401)
            if identity and identity['role']=='institution' and path in {"/api/rules","/api/evidence-graph","/api/export"}:
                return self.json_response({"error":"This operation requires the reviewer role."},403)
            if path == "/api/acknowledgement":
                state=self.store.case()
                if not state.get('submission'):
                    return self.json_response({"error":"Submit the case before downloading its acknowledgement."},400)
                return self.json_response({"case_id":state['id'],"institution":state['institution'],"submission":state['submission'],"notice":"Local demonstration acknowledgement; not an official AICTE receipt."},download=True)
            if path == "/api/scrutiny-plan":
                return self.json_response(scrutiny.signature(self.store))
            if path == "/api/rule-replay":
                if identity['role']!='reviewer':return self.json_response({'error':'Reviewer access required.'},403)
                return self.json_response(self.store._read().get('rule_replay'))
            if path == "/api/precheck":
                return self.json_response(self.portal.precheck())
            if path.startswith("/api/attachments/"):
                aid=path.rsplit('/',1)[-1]
                if not any(a['id']==aid for a in self.store.case().get('attachments',[])):
                    return self.json_response({"error":"Unknown attachment."},404)
                return self.safe_file(self.store.db_path.parent / "uploads", aid+'.pdf')
            if path == "/api/case":
                return self.json_response(self.portal.case_for(identity))
            if path == "/api/rules":
                return self.json_response(load_rules(self.store.root))
            if path == "/api/requirements":
                return self.json_response(self.store.requirements())
            if path == "/api/evidence-graph":
                return self.json_response(self.store.evidence_graph())
            if path == "/api/export":
                return self.json_response(self.store.case(), download=True)
            if path == "/api/health":
                return self.json_response({"ok": True, "mode": "local", "external_connections": False})
            if path.startswith("/api/documents/") and path.endswith("/evidence"):
                return self.json_response(self.store.evidence(unquote(path.split("/")[3])))
            if path.startswith("/documents/"):
                return self.safe_file(ROOT / "documents", path[len("/documents/"):])
            if path.startswith("/api/"):
                return self.json_response({"error": "Unknown API endpoint."}, 404)
            # Static paths are confined to public/ by SimpleHTTPRequestHandler.
            return super().do_GET()
        except (ValueError, FileNotFoundError) as error:
            return self.json_response({"error": str(error)}, 404)
        except Exception as error:
            print(f"Request error: {error}", file=sys.stderr)
            return self.json_response({"error": str(error)}, 500)

    def do_POST(self):
        # Bind localhost; reject cross-origin mutations from unrelated websites.
        origin = self.headers.get("Origin")
        allowed = {f"http://127.0.0.1:{self.server.server_port}", f"http://localhost:{self.server.server_port}"}
        public_host = os.environ.get("RENDER_EXTERNAL_HOSTNAME", "").strip()
        if public_host: allowed.add(f"https://{public_host}")
        if origin and origin not in allowed:
            return self.json_response({"error": "This local demo accepts only same-origin requests."}, 403)
        try:
            path = urlparse(self.path).path
            length = int(self.headers.get("Content-Length", "0"))
            maximum = 7 * 1024 * 1024 + 1024 if path in {"/api/upload", "/api/attachments"} else 32768
            if not 0 <= length <= maximum:
                return self.json_response({"error": "Request body too large."}, 413)
            payload = json.loads(self.rfile.read(length) or b"{}")
            if not isinstance(payload, dict):
                raise ValueError("Expected a JSON object.")
            identity, token = self.session()
            run=self.headers.get('X-Demo-Run','')
            client=self.headers.get('X-Demo-Client','')
            if path == "/api/tour/start":
                if not client or len(client)>100:raise ValueError('A demonstration client identifier is required.')
                new_token,user=self.sessions.login('reviewer',payload.get('username'),payload.get('password'))
                run=self.sessions.begin_tour(client, restart=payload.get("restart") is True)
                self.store.reset()
                return self.json_response({'identity':user,'run':run},cookie=f"np_session={new_token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800")
            if path == "/api/tour/end":
                self.sessions.end_tour(run,client)
                return self.json_response({'ended':True})
            if not self.sessions.check_tour(run,client):
                return self.json_response({'error':'Another walkthrough run owns the demo case. Stop it or start a new walkthrough from this tab.'},409)
            if path in {'/api/tour/checkpoint','/api/tour/restore'}:
                tour=self.sessions.tour
                if not tour or run!=tour['run'] or client!=tour['client']:
                    return self.json_response({'error':'Active walkthrough ownership required.'},403)
                key=str(payload.get('key',''))
                if path.endswith('checkpoint'):
                    tour.setdefault('checkpoints',{})[key]={'state':self.store._read(),'role':identity['role'] if identity else None}
                    return self.json_response({'saved':True})
                saved=tour.get('checkpoints',{}).get(key)
                if not saved:raise ValueError('Scene checkpoint unavailable.')
                with self.store.lock:self.store._write(copy.deepcopy(saved['state']))
                self.sessions.logout(token)
                if saved['role']:
                    account=ACCOUNTS[saved['role']];new_token,user=self.sessions.login(saved['role'],account['username'],account['password'])
                    return self.json_response({'identity':user},cookie=f"np_session={new_token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800")
                return self.json_response({'identity':None},cookie="np_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0")
            if path == "/api/login":
                new_token, user = self.sessions.login(payload.get('role'),payload.get('username'),payload.get('password'))
                self.sessions.logout(token)
                return self.json_response({"identity":user},cookie=f"np_session={new_token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800")
            if path == "/api/logout":
                self.sessions.logout(token)
                return self.json_response({"identity":None},cookie="np_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0")
            if not identity:
                return self.json_response({"error":"Sign in to a demonstration portal."},401)
            reviewer_routes={"/api/analyse","/api/verify","/api/action","/api/rule-preview","/api/decision","/api/reset","/api/attachment-review","/api/rule-replay","/api/rule-activate"}
            institution_routes={"/api/submit","/api/resubmit","/api/respond","/api/attachments"}
            if (path in reviewer_routes and identity['role']!='reviewer') or (path in institution_routes and identity['role']!='institution'):
                return self.json_response({"error":"Your signed-in role cannot perform this operation."},403)
            if path == "/api/rule-replay":return self.json_response(scrutiny.replay(self.store,payload))
            if path == "/api/rule-activate":return self.json_response(scrutiny.activate(self.store,payload))
            if path == "/api/submit":
                return self.json_response(self.portal.submit(payload))
            if path == "/api/respond":
                return self.json_response(self.portal.response(payload))
            if path == "/api/attachments":
                return self.json_response(self.portal.save_attachment(payload))
            if path == "/api/attachment-review":
                return self.json_response(self.portal.assess_attachment(payload))
            if path == "/api/analyse":
                return self.json_response(self.store.analyse())
            if path == "/api/verify":
                return self.json_response(self.store.verify(payload.get("document_id", "")))
            if path == "/api/action":
                return self.json_response(self.store.action(payload.get("finding_id", ""), payload.get("action", ""), payload.get("note", "")))
            if path == "/api/resubmit":
                self.store.resubmit(payload.get("finding_id", ""), payload.get("document_id", ""), payload.get("replacement", ""), payload.get("note", ""))
                return self.json_response(self.portal.case_for(identity))
            if path == "/api/rule-preview":
                return self.json_response(self.store.rule_preview(payload.get("rule_id", ""), payload.get("changes", {})))
            if path == "/api/decision":
                return self.json_response(self.store.decision(payload.get("decision", ""), payload.get("note", "")))
            if path == "/api/upload":
                return self.json_response(self.store.upload(payload.get("filename", ""), payload.get("content_base64", "")))
            if path == "/api/reset":
                return self.json_response(self.store.reset())
            return self.json_response({"error": "Unknown API endpoint."}, 404)
        except (ValueError, TypeError, KeyError) as error:
            return self.json_response({"error": str(error)}, 400)
        except Exception as error:
            print(f"Request error: {error}", file=sys.stderr)
            return self.json_response({"error": str(error)}, 500)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=int(os.environ.get("PORT", "4186")))
    args = parser.parse_args()
    store = CaseStore(db_path=Path(tempfile.gettempdir()) / "niyampramaan-demo" / "case.sqlite3" if os.environ.get("RENDER") else None)
    host = "0.0.0.0" if os.environ.get("RENDER") else "127.0.0.1"
    server = ThreadingHTTPServer((host, args.port), partial(Handler, store=store, sessions=Sessions()))
    print(f"NiyamPramaan local prototype: http://127.0.0.1:{args.port}/", flush=True)
    print("Synthetic case only. Source checks are simulated. Ctrl+C stops the server.", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
